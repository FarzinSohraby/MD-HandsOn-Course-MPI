"""Check that every scientific package required for the MD practical imports."""
import sys
import openmm
import pdbfixer
import mdtraj
import jupyterlab
import py3Dmol
import numpy
import matplotlib
import pandas
import requests

print("Python:", sys.version.split()[0])
print("OpenMM:", openmm.__version__)
print("All required Python packages: OK")
