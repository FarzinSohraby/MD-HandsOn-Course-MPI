﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue' # custom numeric downloader, not PowerShell's moving bar
$folder = $PSScriptRoot
$runtime = Join-Path $folder '.md_runtime'
$miniforge = Join-Path $runtime 'miniforge'
$conda = Join-Path $miniforge 'Scripts\conda.exe'
$mdEnv = Join-Path $runtime 'md-class'
$python = Join-Path $mdEnv 'python.exe'
$notebook = Join-Path $folder 'Windows_Protein_MD_Practical.ipynb'
$check = Join-Path $folder 'CHECK_DEPENDENCIES.py'

function Note([string]$message) { Write-Host "`n[MD Classroom] $message" -ForegroundColor Cyan }
function DownloadFile([string]$url, [string]$destination) {
    Add-Type -AssemblyName System.Net.Http
    $handler = New-Object System.Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect = $true
    $client = New-Object System.Net.Http.HttpClient($handler)
    $client.Timeout = [TimeSpan]::FromMinutes(45)
    $part = "$destination.partial"
    $response = $null
    try {
        $response = $client.GetAsync($url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        $response.EnsureSuccessStatusCode() | Out-Null
        $length = $response.Content.Headers.ContentLength
        $inStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $outStream = [IO.File]::Open($part, [IO.FileMode]::Create, [IO.FileAccess]::Write)
        $buffer = New-Object byte[] 1048576
        $count = [long]0
        $last = [DateTime]::MinValue
        try {
            while (($n = $inStream.Read($buffer,0,$buffer.Length)) -gt 0) {
                $outStream.Write($buffer,0,$n)
                $count += $n
                if (([DateTime]::UtcNow-$last).TotalMilliseconds -ge 800) {
                    $mb = [math]::Round($count/1MB,1)
                    if ($length -and $length -gt 0) {
                        $pct = [math]::Min(100,[math]::Floor($count*100.0/$length))
                        Write-Host ("  Installer download {0}%  ({1:N1} / {2:N1} MB)" -f $pct,$mb,($length/1MB))
                    } else {
                        Write-Host ("  Installer downloaded {0:N1} MB (server did not provide total size)" -f $mb)
                    }
                    $last=[DateTime]::UtcNow
                }
            }
        } finally { $outStream.Dispose();$inStream.Dispose() }
        if ($length -and $count -ne $length) { throw "Incomplete installer download: $count / $length bytes" }
        Move-Item -LiteralPath $part -Destination $destination -Force
        Write-Host ("  Installer download COMPLETE: {0:N1} MB (100%)" -f ($count/1MB)) -ForegroundColor Green
    } finally {
        if ($response) { $response.Dispose() }
        $client.Dispose()
        $handler.Dispose()
    }
}

try {
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'This exercise requires 64-bit Windows.' }
    if (-not (Test-Path -LiteralPath $notebook)) { throw 'Notebook missing: extract the complete ZIP before starting.' }
    New-Item -ItemType Directory -Path $runtime -Force | Out-Null
    if (-not (Test-Path -LiteralPath $conda)) {
        Note 'Stage 1 of 3: installing an isolated Python distribution (first run only)'
        $installer = Join-Path $runtime 'Miniforge3-Windows-x86_64.exe'
        if (-not (Test-Path -LiteralPath $installer)) {
            [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
            DownloadFile 'https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Windows-x86_64.exe' $installer
        }
        if ((Get-Item -LiteralPath $installer).Length -lt 10000000) { throw 'The Miniforge installer is incomplete.' }
        Note 'Installing Miniforge locally. Existing Python installations will not be changed.'
        $args = @('/InstallationType=JustMe','/RegisterPython=0','/AddToPath=0','/NoRegistry=1','/NoShortcuts=1','/S',"/D=$miniforge")
        $proc = Start-Process -FilePath $installer -ArgumentList $args -PassThru -Wait
        if ($proc.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $conda)) { throw "Miniforge installation failed (exit code $($proc.ExitCode))." }
        Note 'Private Miniforge installation complete.'
    } else { Note 'Stage 1 of 3: existing private Miniforge installation found.' }

    if (-not (Test-Path -LiteralPath $python)) {
        Note 'Stage 2 of 3: installing OpenMM, JupyterLab and classroom dependencies'
        Write-Host 'Individual package download and installation progress will be displayed below.'
        $packages=@('python=3.11','jupyterlab>=4,<5','ipykernel','openmm>=8.2,<9',
                    'pdbfixer','mdtraj','numpy','matplotlib','pandas','py3dmol','requests','ipython')
        & $conda create -y --override-channels -c conda-forge -p $mdEnv @packages
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $python)) { throw 'Failed to install the MD environment. See package errors above.' }
    } else { Note 'Stage 2 of 3: existing private MD environment found.' }

    Note 'Stage 3 of 3: verifying the installed scientific packages'
    & $conda run --no-capture-output -p $mdEnv python $check
    if ($LASTEXITCODE -ne 0) { throw 'Package check failed. See error above.' }
    Note 'All checks passed. Opening JupyterLab...'
    Write-Host 'Keep this window open during the exercise. To stop JupyterLab press Ctrl+C here.'
    Set-Location -LiteralPath $folder
    & $conda run --no-capture-output -p $mdEnv python -m jupyter lab $notebook
    if ($LASTEXITCODE -ne 0) { throw 'JupyterLab stopped with an error.' }
} catch {
    Write-Host "`nFAILED: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Please copy this error and show it to your instructor or IT staff.'
    exit 1
}
