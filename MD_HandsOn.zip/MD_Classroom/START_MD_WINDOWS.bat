@echo off
setlocal
cd /d "%~dp0"
title MD Classroom - Windows Setup and JupyterLab
echo =======================================================
echo          MOLECULAR DYNAMICS - STUDENT CLASSROOM
echo =======================================================
echo.
echo  A Python installation is NOT required before starting.
echo  The first run downloads and installs a private environment.
echo  Keep this window open while JupyterLab is running.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP_AND_LAUNCH.ps1"
if errorlevel 1 (
  echo.
  echo SETUP OR STARTUP FAILED. Please show the error above to your instructor.
  pause
  exit /b 1
)
endlocal
